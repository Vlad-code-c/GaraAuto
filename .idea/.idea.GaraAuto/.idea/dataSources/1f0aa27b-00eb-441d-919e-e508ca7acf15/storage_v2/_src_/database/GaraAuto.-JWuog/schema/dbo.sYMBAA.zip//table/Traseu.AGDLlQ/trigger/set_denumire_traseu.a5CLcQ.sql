create trigger set_denumire_traseu
    on Traseu
    after insert
    as
    begin 
        UPDATE  Traseu
        SET denumire = ( SELECT TOP 1 nume FROM Localitate WHERE id = inserted.id_localitate_inceput) + ' - ' +
                       ( SELECT TOP 1 nume FROM Localitate WHERE id = inserted.id_localitate_sfarsit)
        FROM inserted
        WHERE Traseu.id_localitate_inceput = inserted.id_localitate_inceput AND 
              Traseu.id_localitate_sfarsit = inserted.id_localitate_sfarsit
    end;
go

